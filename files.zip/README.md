# BMI Health Summary Calculator

A clean, minimal health tool that calculates BMI and generates a full personalised health summary — including calorie needs, ideal weight range, protein targets, hydration, and body fat estimate.

## Live Demo
> Add your Vercel link here after deployment

## Screenshot
> Add screenshot after deployment

## Features
- BMI calculation with visual range indicator
- Supports Metric (kg/cm) and Imperial (lbs/ft/in)
- Resting Metabolic Rate (BMR) via Mifflin-St Jeor equation
- Total Daily Energy Expenditure (TDEE) by activity level
- Ideal weight range (18.5–24.9 BMI band)
- Daily calorie targets: maintenance, loss, gain
- Protein and hydration recommendations
- Estimated body fat % (BMI method)
- Personalised tips based on BMI category and age
- Fully responsive — works on mobile

## Tech Stack
- HTML5
- CSS3 (custom properties, CSS Grid, Flexbox)
- Vanilla JavaScript (no libraries/frameworks)
- Google Fonts (Inter + DM Serif Display)

## How to Run Locally
```bash
# Just open the file directly — no server needed
open index.html
```
Or right-click `index.html` → Open with browser.

## Deployment (Vercel)
1. Push this folder to a GitHub repo
2. Go to [vercel.com](https://vercel.com) → New Project → Import repo
3. Click Deploy — done, live link in 30 seconds

## Formula References
- BMI: weight(kg) / height(m)²
- BMR: Mifflin-St Jeor equation
- TDEE: BMR × activity multiplier (Harris-Benedict)
- Body fat: Deurenberg approximation

## Disclaimer
This tool is for informational purposes only and does not constitute medical advice. Always consult a qualified healthcare professional.
